import json
import pymongo
from pymongo import MongoClient
import tweepy
import os
from textblob import TextBlob
import re


monogodb_connect = os.environ['mongodb_connect']
database_name= os.environ['database_name']
query = os.environ['q_parameter']     

BEARER_TOKEN = os.environ['twitter_api_key']


mongodb_client = MongoClient(monogodb_connect)
db = mongodb_client[database_name] # use or create a database named demo
tweet_collection = db.tweet_collection #use or create a collection named tweet_collection
tweet_collection.create_index([("tweet.id", pymongo.ASCENDING)],unique = True) # make sure the collected tweets are unique


twitter_client = tweepy.Client(BEARER_TOKEN)


url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'

def lambda_handler(event, context):
    

    tweets = twitter_client.search_recent_tweets(query=query, max_results=10,
                                        expansions=['author_id'], 
                                        tweet_fields = ['created_at','entities','lang','public_metrics','geo'],
                                        user_fields = ['id', 'location','name', 'public_metrics','username'])
    
    i = 0
    for user, tweet in zip(tweets.includes['users'],tweets.data):
        tweet_json = {}
        tweet_json['tweet']= tweet.data
        tweet_json['user'] = user.data
        text_without_urls = re.sub(url_pattern, '', tweet_json['tweet']['text'])
        tweet_text = text_without_urls.replace('\n','')
        result = TextBlob(tweet_text)
        tweet_json['polarity'] = result.sentiment.polarity
        tweet_json['subjectivity'] = result.sentiment.subjectivity

        try:
            
            
            tweet_collection.insert_one(tweet_json)
            # print(tweet_json['tweet']['created_at'])
            i = i+1
        except:
            pass
        
    return {
        'statusCode': 200,
        'body': json.dumps(f"prcessed {i} tweets.")
    }