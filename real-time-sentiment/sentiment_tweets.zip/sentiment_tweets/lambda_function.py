import json

import json
import pymongo
from pymongo import MongoClient

import boto3

aws_client = boto3.client('comprehend')

import os

monogodb_connect = os.environ['mongodb_connect']

database_name= os.environ['database_name']

lang= os.environ['lang']



client = MongoClient(monogodb_connect)
db = client[database_name] # use or create a database named demo
tweet_collection = db.tweet_collection #use or create a collection named tweet_collection
tweet_collection.create_index([("is_sentiment", pymongo.ASCENDING)]) # make sure the collected tweets are unique

def lambda_handler(event, context):
    i=0

    documents = tweet_collection.find({'is_sentiment':None})
    for document in documents: 
        try:
            response = aws_client.detect_sentiment(Text = document['text'],LanguageCode = lang)
            
            # print(response['SentimentScore']['Positive'])
            
            tweet_collection.update_one({'id':document['id']},{ "$set": { "is_sentiment": True,
                                                                    'sentiment':response['Sentiment'], 
                                                                    'positive_score':response['SentimentScore']['Positive'],
                                                                    'negative_score':response['SentimentScore']['Negative'],
                                                                     'neutral_score':response['SentimentScore']['Neutral'],
                                                                    'mixed_score':response['SentimentScore']['Mixed']
            } } )
            i = i+1
        except:
            pass
    print('processed:{} tweets'.format(i))
    return {
        'statusCode': 200
    }
