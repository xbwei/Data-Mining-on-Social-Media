import json
import pymongo
from pymongo import MongoClient
import twitter

import os


CONSUMER_KEY      = os.environ['api_key']
CONSUMER_SECRET   = os.environ['api_secret']
OAUTH_TOKEN       = os.environ['access_token']
OATH_TOKEN_SECRET = os.environ['access_secret']

monogodb_connect = os.environ['mongodb_connect']
database_name= os.environ['database_name']



client = MongoClient(monogodb_connect)
db = client[database_name] # use or create a database named demo
tweet_collection = db.tweet_collection #use or create a collection named tweet_collection
tweet_collection.create_index([("id", pymongo.ASCENDING)],unique = True) # make sure the collected tweets are unique

rest_auth = twitter.oauth.OAuth(OAUTH_TOKEN,OATH_TOKEN_SECRET,CONSUMER_KEY,CONSUMER_SECRET)
rest_api = twitter.Twitter(auth=rest_auth)
    
count = 100 #number of returned tweets, default and max is 100
geocode = os.environ['geocode']  # defin the location, in Harrisonburg, VA
q = os.environ['q_parameter']                               #define the keywords, tweets contain election


def lambda_handler(event, context):
    
    search_results = rest_api.search.tweets( count=count,q=q, geocode=geocode) #you can use both q and geocode
    statuses = search_results["statuses"]

    i = 0
    for statuse in statuses:
        try:
        

            if tweet_collection.count_documents({'id':statuse['id']})==1:
                tweet_collection.update_one({'id':statuse['id']},{'$set':{'favorite_count':statuse['favorite_count']}})
            else:
                tweet_collection.insert_one(statuse)
                i = i+1
        except:
            pass
        
    print('inserted:{} tweets'.format(i))
    
    
    return {
        'statusCode': 200    }
    